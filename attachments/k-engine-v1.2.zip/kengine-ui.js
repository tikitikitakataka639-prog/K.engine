"use strict";
/* K.ENGINE · kengine-ui.js — panel de control, bridge WebLLM↔API, configuración, caché y diagnóstico.
   Se carga DESPUÉS del script principal de index.html y comparte sus globales ($, el, state, getWorker, MODEL_CATALOG...).
   No parchea Cache/fetch. Todo estado mostrado sale de APIs reales del navegador o de server.js. */

const KE = { apiOk: false, cid: null, lastReported: "", job: null, scan: null, rec: null, recs: null, diag: [], lastLoadError: null, hooked: null };
const MB = 1024 * 1024;
const fmtBytes = (n) => (n >= 1024 * MB ? (n / 1024 / MB).toFixed(2) + " GB" : (n / MB).toFixed(1) + " MB");
const setTxt = (id, t, cls) => { const n = document.getElementById(id); if (!n) return; n.textContent = t; if (cls !== undefined) n.className = cls; };
const GOOD = "text-volt", BAD = "text-red2", WARN = "text-amber2", NEUTRAL = "text-slate-200";

/* ---------- Cliente de la API (misma origen que sirve la UI) ---------- */
const tokenGet = () => { try { return sessionStorage.getItem("kengine_token") || ""; } catch { return ""; } };
async function api(path, opts = {}) {
  const h = { ...(opts.headers || {}) };
  if (opts.body) h["Content-Type"] = "application/json";
  const t = tokenGet(); if (t) h.Authorization = "Bearer " + t;
  const r = await fetch(path, { ...opts, headers: h });
  const text = await r.text(); let j = null; try { j = JSON.parse(text); } catch {}
  if (!r.ok) throw Object.assign(new Error((j && j.error) || ("HTTP " + r.status)), { status: r.status });
  return j;
}
async function probeApi() {
  if (!/^https?:$/.test(location.protocol)) { KE.apiOk = false; return; }
  try { const r = await fetch("/health"); const j = await r.json(); KE.apiOk = j && j.engine === "K.ENGINE"; KE.version = j.version; }
  catch { KE.apiOk = false; }
}

/* ---------- Escaneo de caché (Cache API) ---------- */
const isOurs = (n) => /^(webllm|kengine)/i.test(n);
const groupOf = (url) => { const i = url.indexOf("/resolve/"); return i > 0 ? url.slice(0, i) : (() => { try { const u = new URL(url); return u.origin + u.pathname.split("/").slice(0, 3).join("/"); } catch { return url; } })(); };
async function scanCaches() {
  if (!("caches" in window)) return { supported: false, caches: [], groups: new Map(), total: 0, knownBytes: 0, unknown: 0 };
  const names = (await caches.keys()).filter(isOurs);
  const groups = new Map(); let total = 0, knownBytes = 0, unknown = 0;
  for (const name of names) {
    const c = await caches.open(name);
    for (const req of await c.keys()) {
      total++;
      const resp = await c.match(req);
      const len = resp && resp.headers.get("content-length");
      const size = len != null && len !== "" && !isNaN(+len) ? +len : null;
      if (size == null) unknown++; else knownBytes += size;
      const g = groupOf(req.url);
      if (!groups.has(g)) groups.set(g, []);
      groups.get(g).push({ cache: name, req, size, ok: resp ? resp.ok : false, status: resp ? resp.status : 0 });
    }
  }
  return { supported: true, caches: names, groups, total, knownBytes, unknown };
}
async function refreshCache() {
  try {
    const s = KE.scan = await scanCaches();
    let est = ""; try { if (navigator.storage && navigator.storage.estimate) { const e = await navigator.storage.estimate(); est = " · uso total del origen ≈ " + fmtBytes(e.usage || 0) + " de " + fmtBytes(e.quota || 0); } } catch {}
    const txt = !s.supported ? "Cache API no disponible en este contexto."
      : s.total === 0 ? "Sin entradas de WebLLM/K.ENGINE en caché." + est
      : s.caches.length + " cachés · " + s.total + " entradas · " + s.groups.size + " modelo(s)/grupo(s) · tamaño conocido " + fmtBytes(s.knownBytes) + (s.unknown ? " (" + s.unknown + " entradas sin Content-Length)" : "") + est;
    setTxt("cacheSummary", txt);
    setTxt("ksCache", !s.supported ? "NO DISPONIBLE" : s.total === 0 ? "SIN ENTRADAS" : fmtBytes(s.knownBytes) + (s.unknown ? "+" : ""), s.total ? NEUTRAL : "text-slate-400");
    document.getElementById("cacheDelete").disabled = !s.supported || s.total === 0;
    const cs = document.getElementById("cacheStatus"); if (cs && state.status === "NOT_INSTALLED") cs.textContent = s.total ? "CACHE FOUND · " + s.total + " entradas" : "SIN ENTRADAS";
  } catch (e) { setTxt("cacheSummary", "Error al escanear la caché: " + (e && e.message || e)); }
}
const modelBusy = () => ["DOWNLOADING", "LOADING", "READY", "GENERATING", "UNLOADING", "DOWNLOADED"].includes(state.status);

async function deleteCaches() {
  if (modelBusy()) { setTxt("cacheSummary", "Hay un modelo cargado o en proceso (" + state.status + "). Descárgalo de memoria antes de eliminar la caché."); return; }
  const s = await scanCaches(); KE.scan = s;
  if (!s.total) { await refreshCache(); return; }
  const btn = document.getElementById("cacheDelete"); btn.disabled = true;
  const wrap = document.getElementById("cacheBarWrap"), bar = document.getElementById("cacheBar");
  wrap.classList.remove("hidden"); setTxt("cacheTitle", "ELIMINANDO CACHÉ");
  const useBytes = s.unknown === 0 && s.knownBytes > 0;
  let done = 0, freed = 0, groupsDone = 0, failed = [];
  const before = navigator.storage && navigator.storage.estimate ? (await navigator.storage.estimate()).usage : null;
  for (const [g, entries] of s.groups) {
    for (const e of entries) {
      setTxt("cacheDetail", "Eliminando: " + e.req.url.split("/").slice(-2).join("/") + "\nModelos eliminados: " + groupsDone + "/" + s.groups.size + " · Datos liberados (conocidos): " + fmtBytes(freed));
      try { const c = await caches.open(e.cache); const okDel = await c.delete(e.req); if (!okDel) failed.push(e.req.url); } catch (err) { failed.push(e.req.url + " → " + (err && err.message || err)); }
      done++; if (e.size) freed += e.size;
      const pct = useBytes ? Math.floor((freed / s.knownBytes) * 100) : Math.floor((done / s.total) * 100); // por bytes solo si TODAS las entradas tienen tamaño
      bar.style.width = Math.min(pct, 99) + "%"; setTxt("cachePct", Math.min(pct, 99) + "%  (" + done + "/" + s.total + " entradas" + (useBytes ? ", por bytes" : ", por nº de entradas: el navegador no expone todos los tamaños") + ")");
      if (done % 5 === 0) await new Promise(r => setTimeout(r));
    }
    groupsDone++;
  }
  for (const n of s.caches) { try { if ((await (await caches.open(n)).keys()).length === 0) await caches.delete(n); } catch {} }
  const after = await scanCaches(); // verificación real antes de mostrar 100 %
  const left = after.total;
  if (left === 0 && failed.length === 0) { bar.style.width = "100%"; setTxt("cachePct", "100%"); setTxt("cacheTitle", "CACHÉ ELIMINADA"); }
  else { setTxt("cacheTitle", "ELIMINACIÓN INCOMPLETA: quedan " + left + " entradas"); }
  let delta = ""; try { if (before != null) { const a = (await navigator.storage.estimate()).usage; delta = " · uso del origen: " + fmtBytes(before) + " → " + fmtBytes(a) + " (estimación del navegador)"; } } catch {}
  setTxt("cacheDetail", "Entradas eliminadas: " + (s.total - left) + "/" + s.total + " · Modelos/grupos: " + groupsDone + "/" + s.groups.size + " · Liberado (tamaños conocidos): " + fmtBytes(freed) + delta + (failed.length ? "\nFallos (" + failed.length + "):\n" + failed.slice(0, 5).join("\n") : ""));
  await refreshCache();
}

/* ---------- Diagnóstico de descarga (causa real del Cache.add() network error) ---------- */
async function cacheApiSelfTest() {
  if (!("caches" in window)) return { ok: false, detail: "Cache API no disponible (¿contexto no seguro/Origin null?)" };
  try {
    const c = await caches.open("kengine-selftest"); const req = new Request(location.origin + "/__kengine_selftest__");
    await c.put(req, new Response("ok")); const back = await c.match(req); await caches.delete("kengine-selftest");
    return { ok: !!back, detail: back ? "put/match/delete correctos" : "put sin match" };
  } catch (e) { return { ok: false, detail: "falló: " + (e && e.name) + ": " + (e && e.message) }; }
}
function classify(items, selftest) {
  const bad = items.filter(i => !i.ok);
  if (!selftest.ok) return "CAUSA: Cache API del navegador (" + selftest.detail + "). No es la red.";
  if (!bad.length) return "Todos los recursos responden desde el worker y la Cache API funciona. El fallo no es de red/CORS/HF en este momento: revisa cuota de almacenamiento, entradas corruptas en caché o un fallo intermitente.";
  const net = bad.filter(i => i.error), http = bad.filter(i => i.status);
  const parts = [];
  if (net.length) parts.push(net.length + " recurso(s) rechazados por fetch (sin respuesta: red/DNS, CORS, bloqueo por extensión/firewall o redirección sin cabeceras CORS). Primero: " + net[0].url + " → " + net[0].error);
  if (http.length) parts.push(http.length + " recurso(s) con HTTP erróneo. Primero: " + http[0].url + " → " + http[0].status);
  return "CAUSA PROBABLE: " + parts.join(" · ");
}
function renderDiag() { setTxt("diagOut", KE.diag.map(i => (i.ok ? "OK   " : "FALLA") + " " + (i.status || "") + " " + i.url + (i.error ? "\n       " + i.error : "") + (i.redirected ? "\n       → redirigido a " + i.finalUrl : "")).join("\n")); }
let diagResolve = null;
async function runDiagnosis() {
  KE.diag = []; setTxt("diagOut", "Comprobando Cache API y recursos…");
  const st = await cacheApiSelfTest(); let est = "";
  try { const e = await navigator.storage.estimate(); est = "\nAlmacenamiento: usado " + fmtBytes(e.usage || 0) + " / cuota " + fmtBytes(e.quota || 0); } catch {}
  const w = getWorker(); hookWorker();
  const done = new Promise(res => { diagResolve = res; setTimeout(() => res({ timeout: true }), 120000); });
  w.postMessage({ type: "diagnose", model: DEFAULT_MODEL });
  const r = await done; diagResolve = null;
  const head = "Origen: " + location.origin + " · Cache API: " + (st.ok ? "OK" : "FALLA") + " (" + st.detail + ")" + est + "\n";
  const last = r.lastResources && r.lastResources.length ? "\n\nÚltimas peticiones vistas por el worker (Resource Timing):\n" + r.lastResources.map(e => (e.status ?? "?") + " " + e.name).join("\n") : "";
  const verdict = r.workerFailed ? "El worker no pudo iniciar WebLLM, así que no hay sondeo de recursos: " + r.message : r.timeout ? "El worker no respondió al diagnóstico (¿falló al importar WebLLM? mira la consola)." : classify(KE.diag, st);
  setTxt("diagOut", head + "\n" + KE.diag.map(i => (i.ok ? "OK   " : "FALLA") + " " + (i.status || "") + " " + i.url + (i.error ? "\n       " + i.error : "")).join("\n") + last + "\n\n" + verdict);
  document.getElementById("diagFix").classList.remove("hidden");
}
// Solo entradas cacheadas inválidas del modelo seleccionado (respuesta no-OK / vacía / opaca). NO borra el resto.
async function fixAndRetry() {
  if (modelBusy() && state.status !== "ERROR") { setTxt("diagOut", "Hay un modelo en proceso (" + state.status + "); espera o descárgalo de memoria."); return; }
  const s = await scanCaches(); let removed = 0;
  const rec = (KE.recs || []).find(r => r.id === DEFAULT_MODEL); const repo = rec ? rec.url.replace(/\/+$/, "") : null;
  for (const [g, entries] of s.groups) {
    if (repo && g !== repo) continue;
    for (const e of entries) if (!e.ok || e.status === 0 || e.size === 0) { try { if (await (await caches.open(e.cache)).delete(e.req)) removed++; } catch {} }
  }
  setTxt("diagOut", "Entradas inválidas eliminadas: " + removed + (repo ? "" : " (lista de modelos del worker no disponible: se revisaron todos los grupos)") + ". Reintentando UNA vez la carga de " + DEFAULT_MODEL + "…");
  await refreshCache(); showErr("#engineModelError", null);
  setEngineStatus("DOWNLOADING"); setLabStatus("DOWNLOADING"); getWorker().postMessage({ type: "load", model: DEFAULT_MODEL });
}

/* ---------- Enganche al worker (listener adicional; no sustituye a onWorkerMessage) ---------- */
function hookWorker() {
  if (!worker || KE.hooked === worker) return; KE.hooked = worker;
  worker.addEventListener("error", (e) => { if (diagResolve) diagResolve({ workerFailed: true, message: e.message || "error del worker" }); });
  worker.addEventListener("message", (msg) => {
    const d = msg.data;
    if (d.type === "models" && d.records) { KE.recs = d.records; if (KE.recsResolve) KE.recsResolve(); }
    else if (d.type === "diag") { KE.diag.push(d.item); renderDiag(); }
    else if (d.type === "diag_done" && diagResolve) diagResolve(d);
    else if (d.type === "error" && diagResolve && /importar/.test(d.message)) diagResolve({ workerFailed: true, message: d.message });
    else if (d.type === "error" && d.scope === "load") {
      KE.lastLoadError = d.message; refreshStatus();
      if (/Cache|network|fetch/i.test(d.message)) { setTxt("diagOut", "Error de carga detectado. Pulsa DIAGNOSTICAR RECURSOS para identificar el recurso exacto."); }
    }
    else if (d.type === "status" || d.type === "verified" || d.type === "unloaded") { reportState(); refreshStatus(); if (d.type === "unloaded" || d.type === "verified") refreshCache(); }
    if (KE.job) jobFromWorker(d);
  });
}

/* ---------- Bridge: la pestaña actúa como motor WebLLM para POST /chat?backend=webllm ---------- */
async function reportState() {
  if (!KE.apiOk || !KE.cid) return;
  const key = state.status + "|" + DEFAULT_MODEL; if (key === KE.lastReported) return; KE.lastReported = key;
  const loaded = state.status === "READY" || state.status === "GENERATING" ? DEFAULT_MODEL : null;
  try { await api("/bridge/state", { method: "POST", body: JSON.stringify({ client_id: KE.cid, loaded_model: loaded, state: state.status === "GENERATING" ? "READY" : state.status }) }); } catch { KE.lastReported = ""; }
}
function jobFromWorker(d) {
  const j = KE.job; if (!j) return;
  if (d.type === "token" && d.id === j.id) { j.buf += d.delta; if (!j.timer) j.timer = setTimeout(() => flushJob(false), 80); }
  else if (d.type === "gendone" && d.id === j.id) { flushJob(true); }
  else if (d.type === "error" && d.scope === "generate") { j.err = d.message; flushJob(true); }
}
async function flushJob(final) {
  const j = KE.job; if (!j) return; clearTimeout(j.timer); j.timer = null;
  const body = { client_id: KE.cid, job_id: j.jobId };
  if (j.buf) { body.delta = j.buf; j.buf = ""; }
  if (final) { if (j.err) body.error = j.err; else body.done = true; KE.job = null; }
  if (!body.delta && !final) return;
  try { await api("/bridge/chunk", { method: "POST", body: JSON.stringify(body) }); } catch {}
}
function startJob(job) {
  const refuse = (m) => api("/bridge/chunk", { method: "POST", body: JSON.stringify({ client_id: KE.cid, job_id: job.job_id, error: m }) }).catch(() => {});
  if (state.status !== "READY" || state.generating || KE.job) return refuse("La pestaña K.ENGINE no está lista (estado: " + state.status + (state.generating ? ", generando" : "") + ")");
  KE.job = { jobId: job.job_id, id: 1e9 + Math.floor(Math.random() * 1e9), buf: "", timer: null, err: null };
  hookWorker(); streamingNode = null;
  getWorker().postMessage({ type: "generate", id: KE.job.id, model: DEFAULT_MODEL, messages: job.messages, max_tokens: job.max_tokens });
}
async function bridgeLoop() {
  for (;;) {
    if (!KE.apiOk) { await new Promise(r => setTimeout(r, 5000)); continue; }
    try {
      const t = tokenGet(); const r = await fetch("/bridge/events", { headers: t ? { Authorization: "Bearer " + t } : {} });
      if (!r.ok) throw new Error("HTTP " + r.status);
      const rd = r.body.getReader(), dec = new TextDecoder(); let buf = ""; KE.lastReported = "";
      for (;;) {
        const { value, done } = await rd.read(); if (done) break; buf += dec.decode(value, { stream: true });
        let i; while ((i = buf.indexOf("\n\n")) >= 0) {
          const block = buf.slice(0, i); buf = buf.slice(i + 2);
          const ev = /^event: (.+)$/m.exec(block), dt = /^data: (.+)$/m.exec(block); if (!ev || !dt) continue;
          const data = JSON.parse(dt[1]);
          if (ev[1] === "hello") { KE.cid = data.client_id; setTxt("ksBridge", "CONECTADO", GOOD); reportState(); }
          else if (ev[1] === "job") startJob(data);
          else if (ev[1] === "cancel" && KE.job && KE.job.jobId === data.job_id) { getWorker().postMessage({ type: "cancel" }); }
        }
      }
    } catch (e) { /* se reintenta */ }
    KE.cid = null; setTxt("ksBridge", "DESCONECTADO", "text-slate-400");
    await new Promise(r => setTimeout(r, 3000));
  }
}

/* ---------- Estado ---------- */
let lastModels = null;
async function refreshStatus() {
  const s = state.status, w = state.webgpu;
  let cfgv = null; if (KE.apiOk) { try { cfgv = await api("/config"); } catch {} }
  try { lastModels = KE.apiOk ? await api("/models") : null; } catch { lastModels = null; }
  const openaiCfg = lastModels && lastModels.backends["openai-compatible"].configured;
  const chk = lastModels && lastModels.models.find(m => m.backend === "openai-compatible");
  const pref = cfgv ? cfgv.backend : null;
  const active = !KE.apiOk ? "webllm" : pref === "webllm" ? "webllm" : pref === "openai-compatible" ? "openai-compatible" : (openaiCfg ? "openai-compatible" : "webllm");
  if (active === "openai-compatible") {
    const up = chk && chk.provider_check !== "unreachable";
    setTxt("ksEngine", up ? "● ONLINE" : "● OFFLINE (proveedor inaccesible)", up ? GOOD : BAD);
    setTxt("ksBackend", "OPENAI-COMPATIBLE"); setTxt("ksModel", chk ? chk.id + (chk.provider_check === "not_listed" ? " (no listado por el proveedor)" : "") : "—");
  } else {
    const ready = s === "READY" || s === "GENERATING";
    setTxt("ksEngine", ready ? "● ONLINE" : s === "ERROR" ? "● ERROR" : "○ " + s, ready ? GOOD : s === "ERROR" ? BAD : WARN);
    setTxt("ksBackend", "WEBLLM"); setTxt("ksModel", ready ? DEFAULT_MODEL : "— (ninguno cargado)");
  }
  setTxt("ksWebgpu", w ? "READY" + (state.adapter && state.adapter.features && state.adapter.features.has("shader-f16") ? " · shader-f16" : " · sin shader-f16") : "NO DISPONIBLE", w ? GOOD : BAD);
  setTxt("ksApi", KE.apiOk ? "READY (v" + KE.version + ")" : "NO DISPONIBLE (UI servida sin server.js)", KE.apiOk ? GOOD : WARN);
  if (!KE.apiOk) setTxt("ksBridge", "N/A (sin API)", "text-slate-400");
}

/* ---------- Configuración del backend ---------- */
async function loadConfig() {
  if (!KE.apiOk) { setTxt("cfgMsg", "Sin API: abre la UI desde `node server.js` para configurar el backend."); for (const id of ["cfgSave", "cfgTest"]) document.getElementById(id).disabled = true; return; }
  document.getElementById("cfgToken").value = tokenGet();
  try {
    const c = await api("/config");
    document.getElementById("cfgBackend").value = c.backend; document.getElementById("cfgBaseUrl").value = c.base_url; document.getElementById("cfgModel").value = c.model;
    setTxt("cfgKeyState", c.api_key_set ? "(guardada: " + c.api_key + ")" : "(sin definir)");
    setTxt("cfgMsg", "Entorno: " + c.env + " · token " + (c.auth_required ? "exigido" : "no exigido"));
  } catch (e) { setTxt("cfgMsg", e.status === 401 ? "El servidor exige token: escríbelo y pulsa GUARDAR." : e.status === 403 ? "Configuración remota no permitida sin KENGINE_AUTH_TOKEN." : "Error: " + e.message); }
}
async function saveConfig() {
  try { sessionStorage.setItem("kengine_token", document.getElementById("cfgToken").value.trim()); } catch {}
  const body = { backend: document.getElementById("cfgBackend").value, base_url: document.getElementById("cfgBaseUrl").value.trim(), model: document.getElementById("cfgModel").value.trim() };
  const k = document.getElementById("cfgApiKey").value; if (k) body.api_key = k;
  try { const c = await api("/config", { method: "POST", body: JSON.stringify(body) }); document.getElementById("cfgApiKey").value = ""; setTxt("cfgKeyState", c.api_key_set ? "(guardada: " + c.api_key + ")" : "(sin definir)"); setTxt("cfgMsg", "Guardado en la memoria del servidor."); }
  catch (e) { setTxt("cfgMsg", "No se pudo guardar: " + e.message); }
  refreshStatus();
}
async function testConfig() {
  try { const m = await api("/models"); const o = m.models.find(x => x.backend === "openai-compatible");
    setTxt("cfgMsg", o ? "Proveedor: " + o.id + " · comprobación: " + o.provider_check + (m.backends["openai-compatible"].error ? "\n" + m.backends["openai-compatible"].error : "") : "OpenAI-compatible sin configurar (falta base URL y/o modelo)."); }
  catch (e) { setTxt("cfgMsg", "Error: " + e.message); }
}

/* ---------- Selección automática de modelo ---------- */
function evaluate(recs) {
  const ad = state.adapter, res = []; const mem = navigator.deviceMemory;
  for (const m of MODEL_CATALOG) {
    if (m.tier === "VISION") continue;
    const r = recs && recs.find(x => x.id === m.id); const why = [], warn = [];
    if (!state.webgpu) why.push("WebGPU no disponible");
    else if (/q4f16/.test(m.id) && !(ad.features && ad.features.has("shader-f16"))) why.push("el adaptador no expone shader-f16, requerido por la cuantización q4f16");
    if (r && r.vram_required_MB) { if (mem && mem * 1024 < r.vram_required_MB) warn.push("RAM reportada (" + mem + " GB, tope del navegador) < " + r.vram_required_MB + " MB requeridos"); }
    else warn.push("requisito de memoria no disponible (lista del worker no cargada)");
    res.push({ m, why, warn, vram: r && r.vram_required_MB });
  }
  return res;
}
function showRecommendation(recs) {
  const ev = evaluate(recs), ok = ev.filter(e => !e.why.length), out = document.getElementById("recOut"), ap = document.getElementById("recApply");
  const notes = "\n\nNO EXPUESTO POR EL NAVEGADOR: VRAM" + (navigator.deviceMemory ? "" : ", RAM") + ". WebLLM valida los límites reales del adaptador al cargar.\n\nEVALUACIÓN\n" + ev.map(e => (e.why.length ? "✗ " : "✓ ") + e.m.label + (e.vram ? " (" + e.vram + " MB)" : "") + (e.why.length ? " — " + e.why.join("; ") : e.warn.length ? " — aviso: " + e.warn.join("; ") : "")).join("\n");
  if (!ok.length) { out.textContent = "NO HAY MODELO COMPATIBLE\n\nMotivo:\n" + ev.map(e => "- " + e.m.label + ": " + e.why.join("; ")).join("\n") + notes; ap.classList.add("hidden"); KE.rec = null; return; }
  const pick = ok.find(e => !e.warn.some(w => /^RAM/.test(w))) || ok[0]; KE.rec = pick.m;
  out.textContent = "MODELO RECOMENDADO\n" + pick.m.id.replace(/-Instruct.*$/, "").toLowerCase() + "  (" + pick.m.label + ")\n\nMOTIVO\nCumple los requisitos comprobables (WebGPU" + (/q4f16/.test(pick.m.id) ? ", shader-f16" : "") + ") y es el de mayor prioridad del catálogo que los cumple." + notes;
  ap.classList.toggle("hidden", pick.m.id === DEFAULT_MODEL);
}
async function recommend(withWorker) {
  if (withWorker && !KE.recs) {
    setTxt("recOut", "Obteniendo requisitos de WebLLM desde el worker…");
    const w = getWorker(); hookWorker();
    await new Promise(res => { KE.recsResolve = res; w.postMessage({ type: "models" }); setTimeout(res, 15000); });
  }
  showRecommendation(KE.recs);
}
function applyRecommendation() {
  if (!KE.rec) return;
  if (modelBusy()) { setTxt("recOut", document.getElementById("recOut").textContent + "\n\nNo se puede cambiar de modelo con estado " + state.status + ". Descárgalo de memoria antes."); return; }
  const prev = DEFAULT_MODEL; DEFAULT_MODEL = KE.rec.id; updateModelCard(prev, "NOT_INSTALLED"); updateModelCard(DEFAULT_MODEL, "NOT_INSTALLED");
  const n = document.getElementById("labModelName"); if (n) n.textContent = DEFAULT_MODEL;
  document.getElementById("recApply").classList.add("hidden"); showErr("#engineModelError", null);
  refreshStatus();
}

/* ---------- Arranque ---------- */
(async function kengineUiInit() {
  document.getElementById("cacheScan").addEventListener("click", refreshCache);
  document.getElementById("cacheDelete").addEventListener("click", deleteCaches);
  document.getElementById("diagBtn").addEventListener("click", runDiagnosis);
  document.getElementById("diagFix").addEventListener("click", fixAndRetry);
  document.getElementById("cfgSave").addEventListener("click", saveConfig);
  document.getElementById("cfgTest").addEventListener("click", testConfig);
  document.getElementById("recBtn").addEventListener("click", () => recommend(true));
  document.getElementById("recApply").addEventListener("click", applyRecommendation);
  await probeApi(); await loadConfig();
  await refreshCache(); showRecommendation(null);
  await refreshStatus(); bridgeLoop();
  setInterval(() => { hookWorker(); reportState(); refreshStatus(); }, 4000);
})();
