"use strict";
// Punto de extensión para herramientas/búsqueda (p. ej. n8n). Deliberadamente vacío:
// /chat NO ejecuta herramientas a partir de texto del usuario.
module.exports = { enabled: false, registry: {} };
